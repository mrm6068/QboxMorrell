# QBox Development Info

To build this solution you will need Visual Studio 2015 RC including the Visual Studio Tools for Apache Cordova.

For information about installing the Apacha Cordove tools, check out this link: https://msdn.microsoft.com/en-us/library/dn757054.aspx


![](/Source/QBox.Web/Content/Images/Logo.jpg)]

