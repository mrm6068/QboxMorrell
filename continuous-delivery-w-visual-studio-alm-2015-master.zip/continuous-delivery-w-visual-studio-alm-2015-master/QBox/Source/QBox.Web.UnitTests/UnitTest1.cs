﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace QBox.Web.UnitTests
{
    [TestClass]
    public class WebTests
    {
        [TestMethod]
        public void PostQuizResponseShouldStore()
        {
        }
    }
}
