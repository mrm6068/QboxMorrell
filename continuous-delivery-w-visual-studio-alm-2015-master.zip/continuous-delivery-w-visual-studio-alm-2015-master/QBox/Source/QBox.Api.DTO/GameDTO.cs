using System;

namespace QBox.Api.DTO
{
    public class GameDTO
    {
        public int Id { get; set; }
        public DateTime Start { get; set; }
        public DateTime End { get; set; }
    }
}