﻿namespace QBox.Api.DTO
{
    public class AnswerDTO
    {
        public int QuestionId { get; set; }
        public int SelectedAnswer { get; set; }
    }
}