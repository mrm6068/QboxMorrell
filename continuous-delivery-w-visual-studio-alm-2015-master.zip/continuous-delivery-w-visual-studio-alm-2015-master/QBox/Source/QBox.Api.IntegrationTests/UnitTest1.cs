﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace QBox.Api.IntegrationTests
{
    [TestClass]
    public class IntegrationTests
    {
        [TestMethod]
        public void ImportQuestionsFromExcel()
        {


        }
    }
}
