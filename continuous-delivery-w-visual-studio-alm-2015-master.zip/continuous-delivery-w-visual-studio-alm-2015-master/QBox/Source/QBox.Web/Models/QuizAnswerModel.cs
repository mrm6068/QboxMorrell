﻿namespace QBox.Web.Models
{
    public class QuizAnswerModel
    {
        public int Id { get; set; }
        public string AnswerText { get; set; }
    }
}