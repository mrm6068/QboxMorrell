using System.Collections.Generic;

namespace QBox.Web.Models
{
    public class QuizCategoriesViewModel
    {
        public List<QuizCategoryViewModel> Categories { get; set; }

    }
}